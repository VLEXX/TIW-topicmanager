create definer = root@localhost trigger categories_limite_sottocategorie
    before insert
    on categories
    for each row
BEGIN
SET @sons_num = (SELECT COUNT(*) FROM categories WHERE parentId = new.parentId);

if(@sons_num >=10) THEN
  signal sqlstate '40000' set message_text = 'Impossibile inserire ulteriore sottocategoria, verificare il limite massimo impostato';
  end if; 

 

END;

